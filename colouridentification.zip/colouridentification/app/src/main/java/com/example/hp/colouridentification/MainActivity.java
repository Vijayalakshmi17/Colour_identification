package com.example.hp.colouridentification;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3, b4;
    EditText e1;
    private String []str;
    private int i;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.red);
        b2 = findViewById(R.id.yellow);
        b3 = findViewById(R.id.blue);
        b4 = findViewById(R.id.green);
        e1 = findViewById(R.id.input);
        e1.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable r) {


            }


                @Override
                public void beforeTextChanged (CharSequence r,int start, int before, int count){
                    b1.setBackgroundColor(Color.WHITE);
                    b2.setBackgroundColor(Color.WHITE);
                    b3.setBackgroundColor(Color.WHITE);
                    b4.setBackgroundColor(Color.WHITE);
                    b1.setText(" ");
                    b2.setText(" ");
                    b3.setText(" ");
                    b4.setText(" ");


                }

                @Override
                public void onTextChanged (CharSequence r,int start, int before, int count) {
                    String n = e1.getText().toString();
                    String str[] = n.split(",");
                    for (i = 0; i < str.length; i++) {
                        if ((str[i].equals("red"))||(str[i].equals("Red"))||(str[i].equals("RED")))
                        {
                            b1.setText(str[i]);
                            b1.setBackgroundColor(Color.RED);
                        } else if ((str[i].equals("yellow"))||(str[i].equals("Yellow"))||(str[i].equals("YELLOW"))) {
                            b2.setText(str[i]);
                            b2.setBackgroundColor(Color.YELLOW);
                        } else if ((str[i].equals("blue"))||(str[i].equals("Blue"))||(str[i].equals("BLUE"))) {
                            b3.setText(str[i]);
                            b3.setBackgroundColor(Color.BLUE);
                        }  else if ((str[i].equals("green"))||(str[i].equals("Green"))||(str[i].equals("GREEN"))) {
                            b4.setText(str[i]);
                            b4.setBackgroundColor(Color.GREEN);
                        }

                    }
                }


        });
}
}